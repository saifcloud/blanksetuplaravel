@extends('admin::layouts.master')
@section('content')
@include('admin::partials.sidebar');
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2 class="font700">Dashboard</h2>
                </div>            
               <!--  <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ul>
                    <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">Create New</a>
                </div> -->
            </div>
        </div>

        <div class="container-fluid">

            <div class="row clearfix">
                <div class="col-12">
                    <div class="top_report">
                        <div class="row clearfix">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a href="{{ url('admin/agent')}}">
                                <div class="card">
                                    <div class="clearfix">
                                       
                                        <div class="number text-center">
                                            <h5>Agents</h5>
                                            <span class="font700">{{ ($total_agents)? $total_agents:0 }}</span>
                                            <p>TOTAL</p>
                                        </div>
                                    </div>
                                    <div class="status text-center">
                                        <span>{{ ($pending_agent) ? $pending_agent:0 }} Pending</span>|<span>{{ ($confirmed_agent)? $confirmed_agent:0 }} Confirmed</span>
                                    </div>
                                    <!--<div class="progress progress-xs progress-transparent custom-color-blue mb-0 mt-3">-->
                                    <!--    <div class="progress-bar" data-transitiongoal="100"></div>-->
                                    <!--</div>-->
                                    <!-- <small class="text-muted">19% compared to last week</small> -->
                                </div>
                                </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                 <a href="{{ url('admin/investor')}}">
                                <div class="card">
                                    <div class="clearfix">
                                        <div class="number text-center">
                                            <h5>Investors</h5>
                                            <span class="font700">{{ ($total_investors) ? $total_investors:0}}</span>
                                            <p>TOTAL</p>
                                        </div>
                                    </div>
                                     <div class="status text-center">
                                        <span>{{ ($pending_investors) ? $pending_investors:0 }} Pending</span>|<span>{{ ($confirmed_investors) ? $confirmed_investors:0}} Confirmed</span>
                                    </div>
                                    <!--<div class="progress progress-xs progress-transparent custom-color-green mb-0 mt-3">-->
                                    <!--    <div class="progress-bar" data-transitiongoal="100"></div>-->
                                    <!--</div>-->
                                    <!-- <small class="text-muted">19% compared to last week</small> -->
                                </div>
                                  </a>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                 <a href="{{ url('admin/subcategory')}}">
                                <div class="card">
                                    <div class="clearfix">
                                        
                                        <div class="number text-center">
                                            <h6>Investments items</h6>
                                            <span class="font700">{{ ($total_items) ? $total_items:0 }}</span>
                                            <p>TOTAL</p>
                                        </div>
                                        
                                    </div>
                                     <div class="status text-center">
                                        <span>{{ ($inactive_items)? $inactive_items:0 }} Pending</span>|<span>{{ ($active_items) ? $active_items:0 }} Confirmed</span>
                                    </div>
                                    <!--<div class="progress progress-xs progress-transparent custom-color-red mb-0 mt-3">-->
                                    <!--    <div class="progress-bar" data-transitiongoal="100"></div>-->
                                    <!--</div>-->
                                    <!-- <small class="text-muted">19% compared to last week</small> -->
                                </div>
                            </a>
                            </div>
                           <!--  <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="card">
                                    <div class="clearfix">
                                       
                                        <div class="number text-center">
                                            <h6>Likes</h6>
                                            <span class="font700">21,215</span>
                                            <p>TOTAL</p>
                                        </div>
                                    </div>
                                     <div class="status text-center">
                                        <span>5 Pending</span>|<span>39 Confirmed</span>
                                    </div> -->
                                    <!--<div class="progress progress-xs progress-transparent custom-color-yellow mb-0 mt-3">-->
                                    <!--    <div class="progress-bar" data-transitiongoal="100"></div>-->
                                    <!--</div>-->
                                   <!--  <small class="text-muted">19% compared to last week</small> -->
                              <!--   </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    
</div>



@endsection
