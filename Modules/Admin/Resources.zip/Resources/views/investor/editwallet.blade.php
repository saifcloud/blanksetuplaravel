@extends('admin::layouts.master')
@section('content')
@include('admin::partials.sidebar')

    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>{{ $page_title }}</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('admin/dashboard')}}"><i class="icon-home"></i></a></li>
                        <!-- <li class="breadcrumb-item active">{{ $page_title }}</li> -->
                    </ul>
                    <!-- <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">Create New</a> -->
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <div class="table">
                @if(Session::has('success'))
                      <div class="alert alert-success">
                          <h4 class="text-center">{{ Session::get('success') }}</h4>
                      </div>
                @endif
              <div class="row">
              <div class="col-sm-6">

                <h4>Investor Wallet</h4>
                <form action="{{ url('admin/edit-wallet-post')}}" method="POST">
                  @csrf

                  <input type="hidden" name="user_id" value="{{ base64_encode($user->id) }}">
                  <div class="form-group">
                    <label for="email">Amount</label>
                    <input type="number" class="form-control" name="amount" step="0.01" autocomplete="off" value="{{ old('amount')}}">
                     <span style="color: red;">{{ $errors->first('amount')}}</span>
                  </div>
                  <div class="form-group">
                    <label for="pwd">Transaction Type</label>
                    <select class="form-control" name="transaction_type">
                      <option value="">Select</option>
                      <option value="6">Credit</option>
                      <option value="7">Debit</option>
                    </select>
                    <span style="color: red;">{{ $errors->first('transaction_type')}}</span>
                  </div>
                  <div class="checkbox">
                    <!-- <label><input type="checkbox"> Remember me</label> -->
                  </div>
                  <button type="submit" class="btn btn-default">Submit</button>
                </form>
                
               
                </div>
                </div>
           </div>





          
           </div>

        </div>
    </div>
    





@endsection
