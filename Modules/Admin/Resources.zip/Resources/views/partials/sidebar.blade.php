 <div id="rightbar" class="rightbar">
        <ul class="nav nav-tabs-new">
            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#setting">Settings</a></li>
            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#chat">Chat</a></li>            
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="setting">
                <div class="slim_scroll">
                    <div class="card">
                        <h6>Choose Theme</h6>
                        <ul class="choose-skin list-unstyled mb-0">
                            <li data-theme="purple"><div class="purple"></div></li>
                            <li data-theme="green"><div class="green"></div></li>
                            <li data-theme="orange" class="active"><div class="orange"></div></li>
                            <li data-theme="blue"><div class="blue"></div></li>
                            <li data-theme="blush"><div class="blush"></div></li>
                            <li data-theme="cyan"><div class="cyan"></div></li>
                        </ul>
                    </div>
                    <div class="card">
                        <h6>General Settings</h6>
                        <ul class="setting-list list-unstyled mb-0">
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox">
                                    <span>Report Panel Usag</span>
                                </label>
                            </li>
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox" checked>
                                    <span>Email Redirect</span>
                                </label>
                            </li>
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox" checked>
                                    <span>Notifications</span>
                                </label>                      
                            </li>
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox">
                                    <span>Auto Updates</span>
                                </label>
                            </li>
                        </ul>
                    </div>
                    <div class="card">
                        <h6>Account Settings</h6>
                        <ul class="setting-list list-unstyled mb-0">
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox">
                                    <span>Offline</span>
                                </label>
                            </li>
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox" checked>
                                    <span>Location Permission</span>
                                </label>
                            </li>
                            <li>
                                <label class="fancy-checkbox">
                                    <input type="checkbox" name="checkbox" checked>
                                    <span>Notifications</span>
                                </label>                      
                            </li>
                        </ul>
                    </div>                    
                </div>                
            </div>       
            <div class="tab-pane right_chat" id="chat">
                <div class="slim_scroll">
                    <form>
                        <div class="input-group m-b-20">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="icon-magnifier"></i></span>
                            </div>
                            <input type="text" class="form-control" placeholder="Search...">
                        </div>
                    </form>
                    <div class="card">
                        <h6>Recent</h6>                        
                        <ul class="right_chat list-unstyled mb-0">
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/xs/avatar4.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Ava Alexander <small class="float-right">Just now</small></span>
                                            <span class="message">Lorem ipsum Veniam aliquip culpa laboris minim tempor</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>                            
                            </li>
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/xs/avatar5.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Debra Stewart <small class="float-right">38min ago</small></span>
                                            <span class="message">Many desktop publishing packages and web page editors</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>                            
                            </li>
                            <li class="offline">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/xs/avatar2.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Susie Willis <small class="float-right">2hr ago</small></span>
                                            <span class="message">Contrary to belief, Lorem Ipsum is not simply random text</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>                            
                            </li>
                            <li class="offline">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/xs/avatar1.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Folisise Chosielie <small class="float-right">2hr ago</small></span>
                                            <span class="message">There are many of passages of available, but the majority</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>                            
                            </li>
                            <li class="online">
                                <a href="javascript:void(0);">
                                    <div class="media">
                                        <img class="media-object " src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/xs/avatar3.jpg" alt="">
                                        <div class="media-body">
                                            <span class="name">Marshall Nichols <small class="float-right">1day ago</small></span>
                                            <span class="message">It is a long fact that a reader will be distracted</span>
                                            <span class="badge badge-outline status"></span>
                                        </div>
                                    </div>
                                </a>                            
                            </li>                        
                        </ul>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <div id="left-sidebar" class="sidebar">
        <div class="navbar-brand">
            <!-- <a href="{{ url('admin/dashboard')}}"> -->
                <!--<img src="http://www.wrraptheme.com/templates/hexabit/html/assets/images/icon-dark.svg" alt="HexaBit Logo" class="img-fluid logo">-->
                <!-- <span>Admin -->
                <!--<img {{URL::asset('public/uploads/'.Auth::guard('admin')->user()->image)}}  alt="" />-->
                <!-- </span></a> -->
            <button type="button" class="btn-toggle-offcanvas btn btn-sm btn-default float-right"><i class="lnr lnr-menu fa fa-chevron-circle-left"></i></button>
        </div>
        <div class="sidebar-scroll">
            <div class="user-account">
              <!--   <div class="user_div">
                    <img src="{{URL::asset('public/uploads/'.Auth::guard('admin')->user()->image)}}" class="user-photo" alt="User Profile Picture">
                </div> -->
                <div class="dropdown">
                    <span>Welcome,</span>
                    <a href="javascript:void(0);" class="dropdown-toggle user-name" data-toggle="dropdown"><strong>{{Auth::guard('admin')->user()->firstname}}</strong></a>
                    <ul class="dropdown-menu dropdown-menu-right account">
                         <li><a href="{{ url('admin/change-password')}}"><i class="icon-user"></i>Change Password</a></li>
                        <li><a href="{{ url('admin/profile')}}"><i class="icon-user"></i>My Profile</a></li>
                       <!--  <li><a href="app-inbox.html"><i class="icon-envelope-open"></i>Messages</a></li> -->
                      <!--   <li><a href="javascript:void(0);"><i class="icon-settings"></i>Settings</a></li> -->
                        <li class="divider"></li>
                        <li><a href="{{ url('admin/logout')}}"><i class="icon-power"></i>Logout</a></li>
                    </ul>
                </div>
            </div>  
            <nav id="left-sidebar-nav" class="sidebar-nav">
                <ul id="main-menu" class="metismenu">

                    <li class="{{ $page_title == 'dashboard' ? "active":''}}"><a href="{{ url('admin/dashboard')}}"><span>Dashboard</span></a></li>

                      <li class="{{ $page_title == 'Notification List' ? "active":''}}"><a href="{{ url('admin/show-all-notification')}}"><span>Notifications</span></a></li>


                    <li class="{{ $page_title == 'Agent' ? "active":''}}"><a href="{{ url('admin/agent')}}"><span>Agents</span></a></li>

                    <li class="{{ $page_title == 'Investor' ? "active":''}}"><a href="{{ url('admin/investor')}}"><span>Investors</span></a></li>

                   



                    <li class="{{ $page_title == 'Category' || $page_title == 'Pack' || $page_title == 'Subcategory' ? "active":''}}">
                        <a href="#Maps" class="has-arrow "><span>Investment Plan</span></a>
                        <ul>
                            <li class="{{ $page_title == 'Category' ? "active":''}}"><a href="{{ url('admin/category')}}">Categories</a></li>

                            <li class="{{ $page_title == 'Subcategory' ? "active":''}}"><a href="{{ url('admin/subcategory')}}">Items</a></li>

                            <li class="{{ $page_title == 'Pack' ? "active":''}}"><a href="{{ url('admin/pack')}}">Packs</a></li>                            
                        </ul>
                    </li>

                    <!--  <li class="{{ $page_title == 'Setting' ? "active":''}}"><a href="{{ url('admin/setting')}}"><i class="icon-settings"></i><span>Setting</span></a></li> -->



                      <li class="{{ $page_title == 'Social' || $page_title == 'Website' ? "active":''}}">
                        <a href="#Maps"  ><span>Settings</span></a>
                        <ul>
                            <li class="{{ $page_title == 'Social' ? "active":''}}"><a href="{{ url('admin/social')}}">Social links</a></li>
                            
                            <li class="{{ $page_title == 'Mail' ? "active":''}}"><a href="{{ url('admin/mail-setting')}}">Mail Setting</a></li>  

                            <li class="{{ $page_title == 'Website' ? "active":''}}"><a href="{{ url('admin/website-setting')}}">Website Setting</a></li>

                             
                        </ul>
                    </li>


                        <li class="{{ $page_title == 'Transactions' ? "active":''}}"><a href="{{ url('admin/transactions')}}"><span>Transactions</span></a></li>


                      @if(Auth::guard('admin')->user()->role_type==1)
                      <li class="{{ $page_title == 'Sub-Admins' ? "active":''}}"><a href="{{ url('admin/subadmins')}}"><span>Manage Sub-Admin</span></a></li>
                      @endif
                </ul>
            </nav>     
        </div>
    </div>
