@extends('admin::layouts.master')
@section('content')
@include('admin::partials.sidebar');
   <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>{{ $page_title }}</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('admin/dashboard')}}"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item">Agent</li>
                        <li class="breadcrumb-item active">{{ $page_title }}</li>
                    </ul>
                    <!-- <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">Create New</a> -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <!-- <h2>Basic Validation</h2> -->
                        </div>
                        <div class="body">
                            <form id="basic-form" method="post" action="{{ url('admin/add-agent')}}">
                             @csrf
                                 <div class="form-group">
                                    <label for="food">Title</label>
                                    <br/>
                                    <select id="food" name="title" class="form-control">
                                      <option value="">--select--</option>
                                        <option value="1" {{ old('title')==1 ? "selected":""}}>Ms</option>
                                        <option value="2" {{ old('title')==2 ? "selected":""}}>Mr</option>
                                        <option value="3" {{ old('title')==3 ? "selected":""}}>Mrs</option>
                                        
                                    </select>
                                    @if($errors->has('title'))
                                    <p class="text-danger">*{{ $errors->first('title')}}</p>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label>Full Name</label>
                                    <input type="text" class="form-control" name="name" autocomplete="off" value="{{ old('name')}}">
                                     @if($errors->has('name'))
                                    <p class="text-danger">*{{ $errors->first('name')}}</p>
                                    @endif
                                </div>
                                 <div class="form-group">
                                    <label>Phone Number</label>
                                    <input type="number" class="form-control" name="number" autocomplete="off" value="{{ old('number')}}">
                                     @if($errors->has('number'))
                                    <p class="text-danger">*{{ $errors->first('number')}}</p>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" name="email" autocomplete="off" value="{{ old('email')}}">
                                     @if($errors->has('email'))
                                    <p class="text-danger">*{{ $errors->first('email')}}</p>
                                    @endif

                                      @if(session()->has('emailexist'))
                                       <p class="text-danger">*{{ session()->get('emailexist')}}</p>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label>DOB</label>
                                   <input type="text" class="form-control date" name="dob" autocomplete="off">
                                    @if($errors->has('dob'))
                                    <p class="text-danger">*{{ $errors->first('dob')}}</p>
                                    @endif
                                </div>
                                  <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control" name="password">
                                     @if($errors->has('password'))
                                    <p class="text-danger">*{{ $errors->first('password')}}</p>
                                    @endif
                                </div>
                                
                                
                               
                                <br>
                                <button type="submit" class="btn btn-primary">Add</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    
</div>



@endsection
