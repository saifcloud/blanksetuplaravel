@extends('admin::layouts.master')
@section('content')
@include('admin::partials.sidebar');
   <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>{{ $page_title }}</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('admin/dashboard')}}"><i class="icon-home"></i></a></li>
                        <!-- <li class="breadcrumb-item">Agent</li> -->
                        <li class="breadcrumb-item active">{{ $page_title }}</li>
                    </ul>
                    <!-- <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">Create New</a> -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            
            <div class="row clearfix">
                <div class="col-md-12">
                    <div class="card">
                        <div class="header">
                            <!-- <h2>Basic Validation</h2> -->
                        </div>
                        <div class="body">
                            <form id="basic-form" method="post" action="{{ url('admin/update-subadmin')}}">
                             @csrf
                                
                                <input type="hidden" name="subadmins_id" value="{{ base64_encode($admin->id)}}">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input type="text" class="form-control" name="username" autocomplete="off" value="{{ $admin->username }}">
                                     @if($errors->has('username'))
                                    <p class="text-danger">*{{ $errors->first('username')}}</p>
                                    @endif
                                </div>
                                 <div class="form-group">
                                    <label>Firstname</label>
                                    <input type="text" class="form-control" name="firstname" autocomplete="off" value="{{ $admin->firstname }}">
                                     @if($errors->has('firstname'))
                                    <p class="text-danger">*{{ $errors->first('firstname')}}</p>
                                    @endif
                                </div>

                                <div class="form-group">
                                    <label>Lastname</label>
                                    <input type="text" class="form-control" name="lastname" autocomplete="off" value="{{ $admin->lastname }}">
                                     @if($errors->has('lastname'))
                                    <p class="text-danger">*{{ $errors->first('lastname')}}</p>
                                    @endif
                                </div>

                                <div class="form-group">
                                    <label>Email</label>
                                    <input type="email" class="form-control" name="email" autocomplete="off" value="{{ $admin->email }}">
                                     @if($errors->has('email'))
                                    <p class="text-danger">*{{ $errors->first('email')}}</p>
                                    @endif
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                   <input type="password" class="form-control" name="password" autocomplete="off" value="{{ $admin->password }}">
                                    @if($errors->has('password'))
                                    <p class="text-danger">*{{ $errors->first('password')}}</p>
                                    @endif
                                </div>
                                 <!--  <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" class="form-control" name="password">
                                     @if($errors->has('password'))
                                    <p class="text-danger">*{{ $errors->first('password')}}</p>
                                    @endif
                                </div> -->
                                
                                
                               
                                <br>
                                <button type="submit" class="btn btn-primary">Update Subadmin</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    
</div>



@endsection
