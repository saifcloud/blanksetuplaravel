@extends('admin::layouts.master')
@section('content')
@include('admin::partials.sidebar')

<style type="text/css">
  .text_editor{
    margin-left: 30px;
    margin-top: -25px;
  }
   .check-circle{
    /*margin-left: 30px;*/
    /*margin-top: -25px;*/
  }
</style>
    <div id="main-content">
        <div class="block-header">
            <div class="row clearfix">
                <div class="col-md-6 col-sm-12">
                    <h2>{{ $page_title }}</h2>
                </div>            
                <div class="col-md-6 col-sm-12 text-right">
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{ url('admin/dashboard')}}"><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">{{ $page_title }}</li>
                    </ul>
                    <!-- <a href="javascript:void(0);" class="btn btn-sm btn-primary" title="">Create New</a> -->
                </div>
            </div>
        </div>

        <div class="container-fluid">

            <div class="table ">
                @if(Session::has('success'))
                      <div class="alert alert-success">
                          {{ Session::get('success') }}
                      </div>
                @endif

              <div class="row">
              <div class="col-md-6">
                <h4>Basic Details</h4>
             <table class="table table-bordered table-hover table-striped data-table" cellspacing="0">
                   <tr>
                    <th>Name</th>
                    <td>{{ $user->name }}</td>
                  </tr>

                   <tr>
                    <th>Email</th>
                    <td>{{ $user->email }}</td>
                  </tr>

                   <tr>
                    <th>Contact</th>
                    <td>{{ $user->number }}</td>
                  </tr>

                   <!-- <tr>
                     <th>Wallet Balance</th>
                     <td> ₦ <span class="wallet-balance">{{ number_format($user->wallet->balance,2,'.',',') }}</span><a href="javascript:void(0)" class="wallet-bal"><i class="fa fa-check-circle float-right" aria-hidden="true"></i></a></td>
                   </tr> -->

                  <tr>
                    <th>Referral Code</th>
                    <td>{{ $user->referral_code }}</td>
                  </tr>


                   <tr>
                    <th>Agent Plan</th>
                    <td>{{ isset($afp->approve_status) ? $afp->approve_status:"No Subscription" }}</td>
                  </tr>


                   <tr>
                    <th>Activate Agent</th>
                    <td>
                        <form method="post" action="{{ url('admin/approve-agent')}}">
                            @csrf
                        <input type="hidden" name="user_id" value="{{ $user->id }}">
                        <select class="form-control" onchange="this.form.submit()" name="agent_status">
                            <option value="">--Select--</option>
                            <option value="1" {{ $user->is_agent_approved==1 ? "selected":''}}>Approve</option>
                            <option value="2" {{ $user->is_agent_approved==2 ? "selected":''}}>Pending</option>
                            <option value="3" {{ $user->is_agent_approved==3 ? "selected":''}}>Reject</option>
                        </select>
                        </form>
                    </td>
                  </tr>
                    <!-- <th>Name</th> -->
                
                </table>
                </div>



                <div class="col-md-6">
                  <h4>Bank Details</h4>
                    <table class="table table-bordered table-hover table-striped data-table" cellspacing="0">
               
                    <tr>
                    <th>Bank Name</th>
                    <td>{{ isset($user->bank->bank_name) ? $user->bank->bank_name:'No Details' }}</td>
                  </tr>


                    <tr>
                    <th>Account Number</th>
                    <td>{{ isset($user->bank->account_number) ? $user->bank->account_number:'No Details' }}</td>
                  </tr>

                    <tr>
                    <th>Account Name</th>
                    <td>{{ isset($user->bank->bank_account_name) ? $user->bank->bank_account_name:'No Details' }}</td>
                  </tr>
                
                </table>



                 <h4>Wallet Details</h4>
                    <table class="table table-bordered table-hover table-striped data-table" cellspacing="0">
               
                    <tr>
                    <th>Wallet Balance</th>
                    <td> ₦ {{ number_format($user->wallet->balance,2,'.',',') }}</td>
                  </tr>


                    <tr>
                    <th>Action on wallet</th>
                    <td>
                      <form method="post" action="{{ url('admin/action-wallet')}}">
                            @csrf
                        <input type="hidden" name="user_id" value="{{ $user->id }}">
                        <select class="form-control" onchange="this.form.submit()" name="wallet_status">
                            <option value="">--Select--</option>
                            <option value="1" {{ $user->wallet->is_blocked==1 ? "selected":''}} >Block</option>
                            <option value="0" {{ $user->wallet->is_blocked==0 ? "selected":''}}>Unblock</option>
                    
                        </select>
                        </form>
                      </td>
                  </tr>

                    <!-- <tr>
                    <th>Account Name</th>
                    <td>{{ isset($user->bank->bank_account_name) ? $user->bank->bank_account_name:'No Details' }}</td>
                  </tr> -->
                
                </table>
          
                </div>
                </div>
           </div>









              
           

        </div>
    </div>
    





@endsection
