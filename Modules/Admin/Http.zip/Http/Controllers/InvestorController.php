<?php

namespace Modules\Admin\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Auth;
use App\User;
use DataTables;
use Hash;
use App\Wallet;
use App\Notification;
use View;

class InvestorController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
     
          
     public function __construct()
    {
      $notification = Notification::where('is_deleted',0)->latest()->limit(5)->get();
      View::share('unseen',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification_count',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification',$notification);
    }
    
    
    public function index(Request $request)
    {
           $page_title = 'Investor';

        if($request->ajax())
        {
             $data = User::latest()
                    // ->select('users.*','agent_first_plans.approve_status')
                    // ->leftjoin('agent_first_plans','users.id','=','agent_first_plans.user_id')
                    ->where('role',2)
                    ->where('is_deleted',0)
                    ->get();
            return DataTables::of($data)
             ->addIndexColumn()
             ->addColumn('date', function($data){
                 $button = \Carbon\Carbon::parse($data->created_at)->format('d M Y');
                   return $button;
                  })

              ->addColumn('status', function($data){
                        if($data->status == 1)
                        {
                            $button = '<p class="text-success">YES</p>'; 
                        }

                         if($data->status == 0)
                         {
                            $button = '<p class="text-danger">NO</p>'; 
                        }
                         
                        return $button;
                       })
                        

             ->addColumn('action', function($data){
                      

                        $button = '<a href="details-investor/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="edit btn btn-success btn-sm"><i class="fa fa-eye" aria-hidden="true" style="color:black"></i></button></a>';

                       $button .= '&nbsp;&nbsp;&nbsp;<a href="edit-investor/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="edit btn btn-primary btn-sm"><i class="fa fa-edit" aria-hidden="true"></i></button></a>';

                        $button .= '&nbsp;&nbsp;&nbsp;<a href="delete-investor/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="delete btn btn-danger btn-sm"><i class="fa fa-trash" aria-hidden="true"></i></button><a>';
                        return $button;
                    })
                    ->rawColumns(['action','date','status'])
                    ->make(true);
        }
      
        return view('admin::investor.index',compact('page_title'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {   
        $page_title = 'Investor';
        return view('admin::investor.create',compact('page_title'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
        $validateData = $request->validate([
         'title'   =>'required',
         'name'    =>'required',
         'email'   =>'required|email',
         'number'  =>'required',
         'dob'     =>'required',
         'password'=>'required'
        ]);
       

      $user_status =  User::where('email',$request->email)->where('role',2)->first();
          // print_r($user_status); die;
     if(!empty($user_status))
     {
      return redirect()->back()->withInput()->with('emailexist','email is already exist');
     }
        // print_r($request->all());
        $user = new User();
        $user->title    = $request->title;
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->number   = $request->number;
        $user->dob      = $request->dob;
        $user->role     = 2;
        $user->status   = 1;
        $user->password = Hash::make($request->password);
        $user->save();


      $wallet = new Wallet();
      $wallet->user_id =$user->id;
      $wallet->email   =$request->email;
      $wallet->balance  = 00;
      $wallet->save();



        return redirect('admin/investor')->with('success','Investor created successfully');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        $page_title = 'Investor';
        $user = User::find($id);
        // $afp = \DB::table('agent_first_plans')->where('user_id',$id)->first();
        
        $status = $user->status;
        return view('admin::investor.investor_details',compact('page_title','user','status'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $page_title = 'Investor';
        $user = User::find($id);
        return view('admin::investor.edit',compact('page_title','user'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request)
    {
        //
          $validateData = $request->validate([
         'title'   =>'required',
         'name'    =>'required',
         'email'   =>'required|email',
         'number'  =>'required',
         'dob'     =>'required',
         'password'=>'required'
        ]);
           // print_r($request->all());
         $userDetails =  User::find($request->user_id);

         if($userDetails->email == $request->email)
         {
            $user =  User::find($request->user_id);
	        $user->title    = $request->title;
	        $user->name     = $request->name;
	        $user->email    = $request->email;
	        $user->number   = $request->number;
	        $user->dob      = $request->dob;
	        $user->password = Hash::make($request->password);
	        if($user->save())
	        {
	          return redirect('admin/investor')->with('success','Investor updated successfully!!');
	        }else{
	          return redirect('admin/investor')->with('success','Investor cannot created at this time !!');
	        }
         }else{

	         $user_status =  User::where('email',$request->email)->where('role',2)->first();
	            if(!empty($user_status))
	             {
	              return redirect()->back()->withInput()->with('emailexist','email is already exist');
	             }

		        $user =  User::find($request->user_id);
		        $user->title    = $request->title;
		        $user->name     = $request->name;
		        $user->email    = $request->email;
		        $user->number   = $request->number;
		        $user->dob      = $request->dob;
		        $user->password = Hash::make($request->password);
		        if($user->save())
		        {
		          return redirect('admin/investor')->with('success','Investor updated successfully!!');
		        }else{
		          return redirect('admin/investor')->with('success','Investor cannot created at this time !!');
		        }
         }

       
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
        $user = User::find($id);
        $user->is_deleted = 1;
        $user->save();

        return redirect('admin/investor')->with('success','Investor Deleted Successfully');
    }
}
