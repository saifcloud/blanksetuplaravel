<?php

namespace Modules\Admin\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Setting;
use App\Notification;
use View;
use Auth;
use Intervention\Image\ImageManagerStatic as Image;

class SettingController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
     
   public function __construct()
    {
      $notification = Notification::where('is_deleted',0)->latest()->limit(5)->get();
      View::share('unseen',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification_count',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification',$notification);
    }
    
    
    public function index()
    {
        $page_title = 'Social';
        $facebook = Setting::where('field_key','facebook')->first();
        $linkedin = Setting::where('field_key','linkedin')->first();
        $tweeter  = Setting::where('field_key','tweeter')->first();
        $whatsapp = Setting::where('field_key','whatsapp')->first();
        return view('admin::social_links',compact('page_title','facebook','linkedin','tweeter','whatsapp'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create(Request $request)
    {
        // print_r($request->all()); die;
        // $validateData = $request->validate([
                     
        // ]);
        foreach ($request->except('_token') as $key => $value) {
            # code...
            // print_r($key.'-'.$value);
           

            $website_settings = Setting::firstOrCreate(['field_key'=>$key]);
            $website_settings->field_key   = $key;
            $website_settings->field_value = $value;
            $website_settings->save();
   


         if($request->file($key)) {
                

                $image       = $request->file($key);
                // print_r($image); die;
                 // echo public_path('assets/images/phreshfarm_img'.$image) ; die;
                $logoName    = time().'-'.$image->getClientOriginalName();

                $image_resize = Image::make($image->getRealPath());              
                $image_resize->resize(180, 51);
                $image_resize->save(public_path('assets/images/phreshfarm_img/'.$logoName));


            $website_settings = Setting::firstOrCreate(['field_key'=>$key]);
            $website_settings->field_key   = $key;
            $website_settings->field_value = $logoName;
            $website_settings->save();

            }


       }

        return redirect()->back()->with('success','Fields has been updated');
        // return view('admin::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show(Request $request)
    {
        $page_title    = 'Website';
        $website_logo  = Setting::where('field_key','website_logo')->first();
        $website_email = Setting::where('field_key','website_email')->first();
        $contact_1  = Setting::where('field_key','contact_1')->first();
        $contact_2  = Setting::where('field_key','contact_2')->first();
        $contact_3  = Setting::where('field_key','contact_3')->first();
        // $mail_user  = Setting::where('field_key','MAIL_USERNAME')->first();
        // $mail_pass  = Setting::where('field_key','MAIL_PASSWORD')->first();
        return view('admin::website_setting',compact('page_title','website_logo','website_email','contact_1','contact_2','contact_3'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function mail()
    {
        $page_title = 'Mail';
        $mail_user  = Setting::where('field_key','MAIL_USERNAME')->first();
        $mail_pass  = Setting::where('field_key','MAIL_PASSWORD')->first();
        $mail_host  = Setting::where('field_key','HOST')->first();
        return view('admin::mail_setting',compact('page_title','mail_user','mail_pass','mail_host'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function mail_create(Request $request)
    {
        //
        
          foreach ($request->except('_token') as $key => $value) {
            # code...
            // print_r($key.'-'.$value);
           

            $website_settings = Setting::firstOrCreate(['field_key'=>$key]);
            $website_settings->field_key   = $key;
            $website_settings->field_value = $value;
            $website_settings->save();
            
          }
          
           return redirect()->back()->with('success','Mail has been updated');
          
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
