<?php

namespace Modules\Admin\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\User;
use App\Referral_user;
use Hash;
use DataTables;
use App\Wallet;
use App\Admin;
use App\Notification;
use View;
use Auth;



class AgentController extends Controller
{
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
     
  public function __construct()
    {
      $notification = Notification::where('is_deleted',0)->latest()->limit(5)->get();
      View::share('unseen',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification_count',Notification::where('is_deleted',0)->where('status',0)->count());
      View::share('notification',$notification);
    }
    
    public function index(Request $request)
    {   
        $page_title = 'Agent';
         // $data = User::latest()
         //            ->select('users.*','agent_first_plans.approve_status')
         //            ->leftjoin('agent_first_plans','users.id','=','agent_first_plans.user_id')
         //            ->where('role',1)
         //            ->where('is_deleted',0)
         //            ->get();
                    // print_r($data); die;
        if($request->ajax())
        {
             $data = User::latest()
                    ->select('users.*','agent_first_plans.approve_status')
                    ->leftjoin('agent_first_plans','users.id','=','agent_first_plans.user_id')
                    ->where('role',1)
                    ->where('is_deleted',0)
                    ->get();
            return DataTables::of($data)
             ->addIndexColumn()
              ->addColumn('date', function($data){
                       $button = \Carbon\Carbon::parse($data->created_at)->format('d M Y');
                         
                        return $button;
                       })
             ->addColumn('is_approve', function($data){
                        if($data->is_agent_approved == 1)
                        {
                            $button = '<p class="text-success">Active</p>'; 
                        }else if($data->is_agent_approved == 2)
                        {
                           $button = '<p class="text-info">Pending</p>'; 
                        }else if($data->is_agent_approved == 3)
                        {
                            $button = '<p class="text-danger">Reject</p>';
                        }else{
                            $button = '<p class="text-info">Inactive</p>';
                        }
                         
                        return $button;
                       })



                 ->addColumn('status', function($data){
                        if($data->status == 1)
                        {
                            $button = '<p class="text-success">YES</p>'; 
                        }

                         if($data->status == 0)
                         {
                            $button = '<p class="text-danger">NO</p>'; 
                        }
                         
                        return $button;
                       })

              ->addColumn('is_subscribed', function($data){
                        if($data->approve_status == NULL)
                        {
                            $button = 'Not subscribed'; 
                        }else{
                             $button = 'subscribed'; 
                        }
                        // else if($data->is_agent_approved == 2)
                        // {
                        //    $button = '<p class="text-info">Pending</p>'; 
                        // }else if($data->is_agent_approved == 3)
                        // {
                        //     $button = '<p class="text-danger">Reject</p>';
                        // }else{
                        //     $button = '<p class="text-info">No Plan</p>';
                        // }
                         
                        return $button;
                       })
             ->addColumn('action', function($data){
                      

                        $button = '<a href="details-agent/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="edit btn btn-success btn-sm"><i class="fa fa-eye" aria-hidden="true" style="color:black"></i></button></a>';

                       $button .= '&nbsp;&nbsp;&nbsp;<a href="edit-agent/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="edit btn btn-primary btn-sm"><i class="fa fa-edit" aria-hidden="true"></i></button></a>';

                        $button .= '&nbsp;&nbsp;&nbsp;<a href="delete-agent/'.$data->id.'"><button type="button" name="edit" id="'.$data->id.'" class="delete btn btn-danger btn-sm"><i class="fa fa-trash" aria-hidden="true"></i></button><a>';
                        return $button;
                    })
                    ->rawColumns(['action','is_approve','status','date','is_subscribed'])
                    ->make(true);
        }
        $admin = Admin::find(Auth::guard('admin')->id());
        return view('admin::agent.index',compact('page_title','admin'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {   
        $page_title = 'Agent';
        $admin = Admin::find(Auth::guard('admin')->id());
        return view('admin::agent.create',compact('page_title','admin'));
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        //
        $validateData = $request->validate([
         'title'   =>'required',
         'name'    =>'required',
         'email'   =>'required|email',
         'number'  =>'required',
         'dob'     =>'required',
         'password'=>'required'
        ]);


     $user_status =  User::where('email',$request->email)->where('role',1)->first();
          // print_r($user_status); die;
     if(!empty($user_status))
     {
      return redirect()->back()->withInput()->with('emailexist','email is already exist');
     }

        // print_r($request->all());
        $user = new User();
        $user->title    = $request->title;
        $user->name     = $request->name;
        $user->email    = $request->email;
        $user->number   = $request->number;
        $user->dob      = $request->dob;
        $user->role     = 1;
        $user->status   = 1;
        $user->password = Hash::make($request->password);
        $user->save();


      $wallet = new Wallet();
      $wallet->user_id =$user->id;
      $wallet->email   =$request->email;
      $wallet->balance  = 00;
      $wallet->save();


        return redirect('admin/agent')->with('success','User created successfully');
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {   
        $page_title = 'Agent';
        $user = User::find($id);
        $afp = \DB::table('agent_first_plans')->where('user_id',$id)->first();

        $total_referred = Referral_user::where('referral_code',$user->referral_code)
                                        // ->where('role',2)
                                        ->count();
        
        // print_r($afp); die;
         $admin = Admin::find(Auth::guard('admin')->id());
        return view('admin::agent.agent_details',compact('page_title','user','afp','admin','total_referred'));
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $page_title = 'Edit';
        $user = User::find($id);
         $admin = Admin::find(Auth::guard('admin')->id());
        return view('admin::agent.edit',compact('page_title','user','admin'));
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request)
    {
        
         //
        $validateData = $request->validate([
         'title'   =>'required',
         'name'    =>'required',
         'email'   =>'required|email',
         'number'  =>'required',
         'dob'     =>'required',
         'password'=>'required'
        ]);

        // print_r($request->all());
        $userDetails =  User::find($request->user_id);
       

       // if same email
        if($userDetails->email == $request->email)
        {
            $user =  User::find($request->user_id);
            $user->title    = $request->title;
            $user->name     = $request->name;
            $user->email    = $request->email;
            $user->number   = $request->number;
            $user->dob      = $request->dob;
            $user->password = Hash::make($request->password);

            if($user->save())
                {
                  return redirect('admin/agent')->with('success','User updated successfully!!');
                }else{
                  return redirect('admin/agent')->with('success','User cannot created at this time !!');
                }

        }else{
          

            $user_status =  User::where('email',$request->email)->where('role',1)->first();
            if(!empty($user_status))
             {
              return redirect()->back()->withInput()->with('emailexist','email is already exist');
             }

            $user =  User::find($request->user_id);
            $user->title    = $request->title;
            $user->name     = $request->name;
            $user->email    = $request->email;
            $user->number   = $request->number;
            $user->dob      = $request->dob;
            $user->password = Hash::make($request->password);
            if($user->save())
            {
              return redirect('admin/agent')->with('success','User updated successfully!!');
            }else{
              return redirect('admin/agent')->with('success','User cannot created at this time !!');
            }

        }

        // print_r($user); die;
       

       

    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
        $user = User::find($id);
        $user->is_deleted = 1;
        $user->save();


        return redirect('admin/agent')->with('success','User Deleted Successfully');
    }



    public function approve_agent(Request $request)
    {
     // print_r($request->all()); die;
        $user = User::find($request->user_id);
        $user->is_agent_approved = $request->agent_status;
        $user->save();

        if($request->agent_status==1)
        {
            $msg ='activated';
        }

         if($request->agent_status==2)
        {
            $msg ='in pending';
        }

         if($request->agent_status==3)
        {
            $msg ='rejected';
        }
        return redirect()->back()->with('success','Agent account is "'.$msg.'" successfully');
    }
}
