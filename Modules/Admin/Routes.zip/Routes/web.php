<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('admin', 'LoginController@index');
 Route::post('admin/login-post', 'LoginController@create');

Route::group(['prefix'=>'admin','middleware' => ['admin']],function() {
   
    Route::get('dashboard', 'AdminController@index');
    Route::get('change-password', 'AdminController@change_password');
    Route::post('change-password-post','AdminController@change_password_post');

    Route::get('logout', 'AdminController@logout');

    Route::get('profile', 'AdminController@show');
    Route::post('profile-post','AdminController@store');
    // agents 
    Route::get('agent', 'AgentController@index');

    Route::get('create-agent', 'AgentController@create');
    Route::post('add-agent','AgentController@store');

    Route::get('edit-agent/{id}', 'AgentController@edit');
    Route::post('edit-agent','AgentController@update');

    Route::get('details-agent/{id}','AgentController@show');
    Route::get('delete-agent/{id}','AgentController@destroy');

    Route::post('approve-agent','AgentController@approve_agent');

  
   // investor  

 
    Route::get('investor', 'InvestorController@index');

    Route::get('create-investor', 'InvestorController@create');
    Route::post('add-investor','InvestorController@store');

    Route::get('edit-investor/{id}', 'InvestorController@edit');
    Route::post('edit-investor','InvestorController@update');

    Route::get('details-investor/{id}','InvestorController@show');
    Route::get('delete-investor/{id}','InvestorController@destroy');


    Route::post('approve-investor','AgentController@approve_agent');




    //category 
    Route::get('category','CategoryController@index');
    Route::get('create-category','CategoryController@create');
    Route::post('store-category','CategoryController@store');
    Route::get('edit-category/{id}','CategoryController@edit');
    Route::post('update-category','CategoryController@update');
    
    Route::post('status-category','CategoryController@status');
    Route::get('delete-category/{id}','CategoryController@destroy');



      //subcategory 
    Route::get('subcategory','SubcategoryController@index');
    Route::get('create-subcategory','SubcategoryController@create');
    Route::post('store-subcategory','SubcategoryController@store');
    Route::get('edit-subcategory/{id}','SubcategoryController@edit');
    Route::post('update-subcategory','SubcategoryController@update');
    
    Route::post('status-subcategory','SubcategoryController@status');
    Route::get('delete-subcategory/{id}','SubcategoryController@destroy');





      //plans 
    Route::get('pack','PackController@index');
    Route::get('create-pack','PackController@create');
    Route::post('store-pack','PackController@store');
    Route::get('edit-pack/{id}','PackController@edit');
    Route::post('update-pack','PackController@update');
    
    Route::post('status-pack','PackController@status');
    Route::get('delete-pack/{id}','PackController@destroy');



    //setting
    Route::get('social','SettingController@index');
    Route::post('social-post','SettingController@create');

    //mail setting
    Route::get('mail-setting','SettingController@mail');
    Route::post('mail-post','SettingController@mail_create');

    //website setting
    Route::get('website-setting','SettingController@show');
    Route::post('website-post','SettingController@create');

    


      //subadmins create 
    Route::get('subadmins','AdminController@subadmins');
    Route::get('create-subadmin','AdminController@create_subadmins');
    Route::post('store-subadmin','AdminController@store_subadmins');
    Route::get('edit-subadmin/{subadmin_id}','AdminController@edit_subadmins');
    Route::post('update-subadmin','AdminController@update_subadmins');
    
    // Route::post('status-category','AdminController@status_subadmins');
    Route::get('delete-subadmin/{subadmin_id}','AdminController@delete_subadmins');
   

   //investor send verification email
    Route::get('send-verification/{user_id}','AdminController@send_verification');


   //investor verification manually
    Route::get('manually-verification/{user_id}','AdminController@manually_verification');


    //wallet 
    Route::post('action-wallet','AdminController@action_wallet');

    Route::get('edit-wallet/{id}','AdminController@edit_wallet');

    Route::post('edit-wallet-post','AdminController@edit_wallet_post');


    Route::get('transactions','AdminController@transactions');
    
    Route::post('get-notification','AdminController@get_notification');

    Route::get('show-all-notification','AdminController@show_all_notification');

    Route::get('show-details-by-notification/{notification_id}','AdminController@show_details_by_notification');





  
});
